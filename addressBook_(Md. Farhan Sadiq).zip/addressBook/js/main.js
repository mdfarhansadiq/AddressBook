// Selecting DOM
const submit1 = document.getElementById("submitV");
const submit2 = document.getElementById("submitClr");
const submit3 = document.getElementById("submitS");
const result = document.getElementById("result");
var finaltxt = "";
var a = [], b = [], c = [], d = [];
// Function
function submitV(e) {
  e.preventDefault();
  var nTitle = document.getElementById("nameTitle").value;
  var surTitle = document.getElementById("surnameTitle").value;
  var phoneN = document.getElementById("phoneNumber").value;
  var uAddress = document.getElementById("userAddress").value;
  var table = document.getElementById("myTable");
  var row = table.insertRow(0);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  var cell3 = row.insertCell(2);
  var cell4 = row.insertCell(3);

  if(nTitle !== "" && nTitle !== " ")
  {
    cell1.innerHTML = nTitle;
    a.push(nTitle);
  }
  if(surTitle !== "" && surTitle !== " ")
  {
    cell2.innerHTML = surTitle;
    b.push(surTitle);
  }
  if(phoneN !== "" && phoneN !== " ")
  {
    cell3.innerHTML = phoneN;
    c.push(phoneN);
  }
  if(uAddress !== "" && uAddress !== " ")
  {
    cell4.innerHTML = uAddress;
    d.push(uAddress);
  }
}

function allClear(e) {
  e.preventDefault();
  document.getElementById("nameTitle").value = "";
  document.getElementById("surnameTitle").value = "";
  document.getElementById("phoneNumber").value = "";
  document.getElementById("userAddress").value = "";
}

function submitS(e)
{
  e.preventDefault();
  var searchN = document.getElementById("searchName").value;
  //console.log(searchN);
  var n, sur, p, addrs;
  for(var i = 0; i < a.length; i++)
  {
    if(searchN === a[i])
    {
      console.log(a[i]);
      // console.log(b[i]);
      // console.log(c[i]);
      // console.log(d[i]);
      document.getElementById("result1").innerHTML = a[i];
      document.getElementById("result2").innerHTML = b[i];
      document.getElementById("result3").innerHTML = c[i];
      document.getElementById("result4").innerHTML = d[i];
      break;
    }
  }
}


submit1.addEventListener("click", submitV);
submit2.addEventListener("click", allClear);
submit3.addEventListener("click", submitS);